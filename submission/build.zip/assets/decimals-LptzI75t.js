import{ag as c}from"./signing-CvCjQ8LM.js";const a="0x313ce567",n=[],o=[{type:"uint8"}];async function s(t){return c({contract:t.contract,method:[a,n,o],params:[]})}export{s as d};
