import{g as o}from"./signing-Cy385egz.js";async function r(e,t){return await e({method:"eth_getStorageAt",params:[o(t.address),t.position,t.blockTag??"latest"]})}export{r as e};
