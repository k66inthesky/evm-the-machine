import{aZ as r}from"./signing-BpJ1XvkG.js";function c(e){const t=Array.isArray(e.method)?e.method[0]:r(e.method);return e.availableSelectors.includes(t)}export{c as d};
