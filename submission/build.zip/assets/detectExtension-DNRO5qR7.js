import{aZ as r}from"./signing-Cy385egz.js";function c(e){const t=Array.isArray(e.method)?e.method[0]:r(e.method);return e.availableSelectors.includes(t)}export{c as d};
